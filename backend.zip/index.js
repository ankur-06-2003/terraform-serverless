require('dotenv').config()
const express = require('express')
const app = express()
const mongoose = require('mongoose')
const regrouter = require('./Routers/Registration')
const PORT = process.env.PORT || 8080
const path = require('path')
const cors = require('cors')   // ✅ better than manual headers

// Middlewares
app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, '/views'))
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
app.use(cors())  // ✅ replaces manual headers

// MongoDB connection (moved to .env for security)
const atlasurl = process.env.MONGO_URI
mongoose.connect(atlasurl, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("✅ MongoDB connection successful")
    })
    .catch((e) => {
        console.log("❌ Connection failed:", e.message)
    })


// Routes
app.get('/', (req, res) => {
    res.render('Home')
})

app.use('/registration', regrouter)

// Handle 404
app.use((req, res) => {
    res.status(404).json({ error: "Route not found" })
})

// Start server
app.listen(PORT, () => {
    console.log(`🚀 App listening on port ${PORT}`)
})
